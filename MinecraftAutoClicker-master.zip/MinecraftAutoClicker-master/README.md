Minecraft Auto Clicker

* Be sure to go into options.txt in your .minecraft folder and set "pauseOnLostFocus" to "false"
* Must be done with Minecraft closed

To access your .minecraft folder, open explorer and paste this into the address bar:
* %appdata%\\.minecraft

Alternatively, you can also do F3 + P in game until it says "Pause on lost focus: disabled"

To Use:

Line yourself up for whatever action you want to take and then bring up the menu. Go into the application and click "Start".

Once you click start, you will have 3 seconds to go into the game and exit the menu. When the countdown hits 0, the program will run and will auto tab you out of the game.

When you want to stop, click "Stop" and it will stop the action.

中文版介绍

使用前需要关闭`失去焦点时暂停游戏`选项，关闭方法如下：
* 在游戏中按快捷键`F3 + P`，提示`失去焦点时暂停游戏：禁用`

或者
* 在资源管理器的地址栏中输入`%appdata%\\.minecraft`
* 打开`options.txt`，将`pauseOnLostFocus`设置为`fasle`

使用指南（以后台挂机钓鱼为例，与原文有所不同）：

* 打开游戏和点击程序，将游戏调整至所需状态（如手持鱼竿处于钓鱼的合适位置）
* 切换回程序，选中`Right Click`和`Hold Click Button Down (For Mining)`，点击`Start`
* 等待三秒，程序运行，开始后台自动钓鱼
